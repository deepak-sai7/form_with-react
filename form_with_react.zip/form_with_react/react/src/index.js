import React from 'react';
import ReactDOM from 'react-dom';
//import App from "./App";
import Form from './Form'
ReactDOM.render(<Form/>, document.getElementById('root'));


